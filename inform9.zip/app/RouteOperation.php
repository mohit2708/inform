<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RouteOperation extends Model
{
    protected $table = 'tbl_operation_on_route';
    protected $primarykey = 'id';
}
